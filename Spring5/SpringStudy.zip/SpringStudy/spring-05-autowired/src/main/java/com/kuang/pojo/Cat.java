package com.kuang.pojo;

public class Cat {
    public void shout(){
        System.out.println("喵~");
    }
}
