package com.kuang.config;

import org.springframework.context.annotation.Configuration;

@Configuration
public class KuangConfig2 {
}
