package com.kuang.demo03;

//租房
public interface Rent {
    public void rent();
}
