package com.kuang.demo01;

//租房
public interface Rent {
    public void rent();
}
