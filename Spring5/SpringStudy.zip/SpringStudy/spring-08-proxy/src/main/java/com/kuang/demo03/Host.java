package com.kuang.demo03;

//房东
public class Host implements Rent {
    public void rent(){
        System.out.println("房东要出租房子！");
    }
}
