package com.kuang.service;

public interface UserService {
    public void add();
    public void delete();
    public void update();
    public void select();
}
