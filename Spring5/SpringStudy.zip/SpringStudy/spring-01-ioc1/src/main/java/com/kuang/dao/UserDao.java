package com.kuang.dao;

public interface UserDao {
    void getUser();
}
