package com.kuang.dao;

public class UserDaoSqlserverImpl implements UserDao{

    @Override
    public void getUser() {
        System.out.println("Sqlserver获取用户数据！");
    }
}
